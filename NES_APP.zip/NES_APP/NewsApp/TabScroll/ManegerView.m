//
//  ManegerView.m
//  NewsApp
//
//  Created by 陈玉乐 on 2018/6/12.
//  Copyright © 2018年 陈玉乐. All rights reserved.
//

#import "ManegerView.h"
#import "TabManger.h"
#import "ManagerConfig.h"


@interface ManegerView () <UITableViewDataSource, UITableViewDelegate>

@property(weak,nonatomic) id <ManegerViewDataSource> dataSource;

@property(weak,nonatomic) UIViewController *currentViewController;

@property(assign ,nonatomic) CGFloat headerHeight;

@property(strong,nonatomic) UIView*headerView;

@property(strong,nonatomic) ManagerConfig *managerConfig;

@property(strong,nonatomic) TabManger *tabManger;

@property (nonatomic, strong) UITableView  *table;

@property(assign ,nonatomic) CGFloat currenty;

@property(weak ,nonatomic) UIScrollView *currentsrc;



@end


@implementation ManegerView


-(instancetype)initWithFrame:(CGRect)frame currentViewController:(UIViewController *)viewController manegerViewDataSource:(id<ManegerViewDataSource>)dataSource{
    

    if (self = [super initWithFrame:frame]) {
        
        _currentViewController = viewController;
        _dataSource = dataSource;
    }
    
    return self;
}


-(void)loadViews{
    
    if (!_dataSource) {
        
        return;
    }

    
    if ([self.dataSource numberOfPage] == 0) {
        return;
    }
    
    if ([self.dataSource respondsToSelector:@selector(headerView)]) {
        
        _headerView = [self.dataSource headerView];
    }
    
    if ([self.dataSource respondsToSelector:@selector(managerConfig)]) {
        
        _managerConfig = [self.dataSource  managerConfig];
    }
    
    if (!_managerConfig) {
        
        _managerConfig = [ManagerConfig new];
    }

    [self addContentView];
    
}



-(void)addContentView{
    
    _headerHeight = 0.0;
    if (_headerView) {
        _headerHeight = CGRectGetHeight(_headerView.bounds);
        [self addSubview:_headerView];
    }
    
    __weak typeof(self) weakSelf = self;
    
    _tabManger = [[TabManger alloc] initWithFrame:self.bounds viewController:_currentViewController managerConfig:_managerConfig manegerViewDataSource:_dataSource];
    
    _tabManger.contentScollerDidScroll = ^(UIScrollView *src) {
        
        if (!weakSelf.currentsrc || weakSelf.currentsrc != src) {
            
            weakSelf.currentsrc = src;
            weakSelf.currenty = src.contentOffset.y;
            return ;
        }
        
        //向上滑动
        if (src.contentOffset.y >  weakSelf.currenty ) {
            
            
            if (src.contentOffset.y > 0) {
                
                if (weakSelf.table.contentOffset.y < weakSelf.headerHeight) {
                    
                    
                    [UIView animateWithDuration:0.3 animations:^{
                        
                        [weakSelf.table setContentOffset:CGPointMake(0, weakSelf.headerHeight)];
                    }];
                }
                
            }
            
            
        }else{
          //向下滑动
            
            if (src.contentOffset.y < 0) {
                
                [UIView animateWithDuration:0.3 animations:^{
                    
                    [weakSelf.table setContentOffset:CGPointMake(0, 0)];
                }];
            }
            
        }
        
        weakSelf.currenty = src.contentOffset.y;
        
    };
    
    if (!self.table) {
        
        self.table = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStyleGrouped];
        self.table.separatorColor = [UIColor clearColor];
        self.table.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.bounds), 0.1)];
        self.table.tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.bounds), 0.1)];
        self.table.dataSource = self;
        self.table.delegate = self;
        self.table.rowHeight = CGRectGetHeight(self.bounds);
        self.table.sectionHeaderHeight = _headerHeight;
        self.table.sectionFooterHeight = 0.01;
        self.table.bounces = NO;
        self.table.showsVerticalScrollIndicator = NO;
        [self addSubview:self.table];
    }
    
    [self.table reloadData];
}

#pragma mark - UITableViewDataSource, UITableViewDelegate

- (NSInteger )numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger )tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *idenfifier = @"Idenfifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:idenfifier];
    
    if (!cell) {
        
        [_tabManger removeFromSuperview];
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:idenfifier];
        
        [cell addSubview:_tabManger];
    }
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    
    return self.headerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return self.headerHeight;
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
    if (scrollView.contentOffset.y > self.headerHeight) {
        
        scrollView.contentOffset = CGPointMake(0, self.headerHeight);
    }
}


@end
