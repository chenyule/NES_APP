//
//  TabScrollView.m
//  NewsApp
//
//  Created by 陈玉乐 on 2018/6/12.
//  Copyright © 2018年 陈玉乐. All rights reserved.
//

#import "TabScrollView.h"
#import "UIViewController+ScrollerView.h"
#import "UIScrollView+ScollerBlock.h"

@interface TabScrollView ()<UIScrollViewDelegate>

@property(weak,nonatomic) UIViewController *controller;
@property(weak,nonatomic) id <ManegerViewDataSource> dataSource;
@property(assign,nonatomic) CGFloat topOffSety;

@end

@implementation TabScrollView

-(instancetype)initWithFrame:(CGRect)frame viewController:(UIViewController *)controller manegerViewDataSource:(id <ManegerViewDataSource>)dataSource topOffsety:(CGFloat )offset {
    
    if (self = [super initWithFrame:frame]) {
        
        _controller = controller;
        _dataSource = dataSource;
        _topOffSety = offset;
        self.pagingEnabled = YES;
        self.showsHorizontalScrollIndicator = NO;
        self.bounces = NO;
        
        [self loadView];
    }
    
    return self;
}


-(void)loadView{
    
    if (!_dataSource) {
        
        return;
    }
    
    NSInteger page = [self.dataSource numberOfPage];
    
    if (page == 0) {
        
        return;
    }
    
    NSInteger defaultIndex = 0;
    
    [self setContentSize:CGSizeMake(page*self.frame.size.width, self.frame.size.height)];
    
    if ([self.dataSource respondsToSelector:@selector(defaultSelectIndex)]) {
        
        NSInteger defultSelect = [self.dataSource defaultSelectIndex];
        NSInteger pageCount = [self.dataSource numberOfPage];
        
        if (defultSelect > pageCount -1) {
            
            defaultIndex = 0;
        }else{
            
           defaultIndex = defultSelect;
        }
    }else{
        
       defaultIndex = 0;
    }
    
    [self addViewContrllerAtIndex:defaultIndex];
    [self setContentOffset:CGPointMake(defaultIndex* self.frame.size.width, 0)];
}



-(void)addViewContrllerAtIndex:(NSInteger )index{
    
    UIViewController *vieController = [self.dataSource viewControllerAtIndex:index];
    
    if ([self.controller.childViewControllers containsObject:vieController]) {
        
        return;
    }
    
    [self.controller addChildViewController:vieController];
    
    vieController.view.frame = CGRectMake(index*CGRectGetWidth(self.frame), 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
    
    [vieController.contentScrollView setContentInset:UIEdgeInsetsMake(_topOffSety, 0, 0, 0)];
    
    [self addSubview:vieController.view];
    
    __weak typeof(self) weakSelf = self;
    
    vieController.contentScrollView.scollerBlock = ^(UIScrollView *src) {
        
        if (weakSelf.contentScollerDidScroll) {
            
            weakSelf.contentScollerDidScroll(src);
        }
    };
    
    
}


-(NSInteger )currentPage{
    
    if (self.bounds.size.width == 0 || self.bounds.size.height == 0) {
        return 0;
    }
    NSInteger index =  (self.contentOffset.x + self.bounds.size.width * 0.5) / self.bounds.size.width;
    
    return MAX(0,index);
    
}


@end
