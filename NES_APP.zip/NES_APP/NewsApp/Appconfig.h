//
//  Appconfig.h
//  NewsApp
//
//  Created by 陈玉乐 on 2018/6/14.
//  Copyright © 2018年 陈玉乐. All rights reserved.
//

#ifndef Appconfig_h
#define Appconfig_h

#define KIsiPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)

#endif /* Appconfig_h */
